# Grounded Timeline Index (GTI) – Starter Repo

This is a **production-leaning scaffold** for detecting a *phase-coherent, common-mode timing component*
across independent measurement streams (TAI/GNSS/VLBI/PTA, etc.). It implements the math we discussed:

- Residual extraction (assumed provided upstream)
- Whitening/normalization
- Cross-spectral coherence (simplified here; swap in multitaper in your environment)
- PCA/CCA first-mode extraction
- Hilbert analytic phase to estimate **phase gap** vs. a reference
- **GTI(t)** metric and **time-to-overlap** estimate

> This starter uses **synthetic data** to demonstrate the method end-to-end. Swap the CSVs with real feeds.

## Repo Layout

- `generate_synthetic.py` — makes 4 synthetic residual streams with a shrinking phase gap
- `gti_pipeline.py` — core functions (whitening, coherence, PCA, phase gap, GTI, T_overlap)
- `run_demo.py` — runs the pipeline on synthetic data, writes plots + metrics JSON
- `data/` — synthetic CSVs
- `outputs/` — charts + `metrics.json`

## Quick Start

```bash
# 1) (Optional) create venv & install requirements
python -m venv .venv && source .venv/bin/activate
pip install numpy scipy matplotlib scikit-learn pandas

# 2) generate synthetic streams
python generate_synthetic.py

# 3) run pipeline
python run_demo.py
```

## Swapping in Real Data (outline)

You provide **residuals** per stream as CSVs with columns:
- `t` = timestamp (ISO8601 or seconds since epoch)
- `value` = residual time/phase/TOA offset after standard models are removed

Examples to target:
- **TAI/UTC/TT**: BIPM Circular-T per-lab offsets (post site corrections)
- **GNSS clocks**: IGS clock products residuals (after relativistic/iono/tropo corrections)
- **VLBI/DSN**: group-delay or Doppler residuals (quasar/probe)
- **PTA**: pulsar TOA residuals (post standard models)

Put them into `data/stream_*.csv` (at least 3 distinct streams). Then run `run_demo.py`.

## Math (short)

1. Stack whitened residuals R(t) ∈ ℝ^(N×T)
2. Identify coherent band (simplified here with wideband correlation)
3. PCA on covariance of R → first component c(t)
4. Reference sinusoid a(t) derived from nominal Sun-clock band (here: the synthetic baseline)
5. Hilbert phases θ_c, θ_a → Δφ(t) = unwrap(θ_c - θ_a)
6. GTI(t) = median pairwise coherence × variance_explained(first mode) × exp(-|Δφ(t)|)
7. T_overlap ≈ |Δφ| / max(ε, -Δφ̇)

## Disclaimers

- This starter uses `scipy.signal.coherence` for simplicity. Replace with **multitaper** in production.
- No external data is fetched here (offline environment). Hooks & docstrings indicate where to plug feeds.
- Use **pre-registered thresholds** and blind analysis to avoid overfitting.

— Generated: 2025-08-08T12:41:40.069049Z
