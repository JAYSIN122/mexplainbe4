
import numpy as np
import pandas as pd
from scipy.signal import hilbert, coherence
from sklearn.decomposition import PCA

def whiten(z):
    z = np.asarray(z)
    z = z - np.nanmean(z)
    std = np.nanstd(z) + 1e-12
    return z / std

def pairwise_coherence(streams, fs=20.0, nperseg=512):
    # returns matrix of mean coherence across low frequency band (here broad simplification)
    n = len(streams)
    C = np.zeros((n,n))
    for i in range(n):
        for j in range(n):
            if i==j:
                C[i,j]=1.0
            elif i<j:
                f, c = coherence(streams[i], streams[j], fs=fs, nperseg=nperseg)
                # focus on the fundamental vicinity (0.8..1.2 Hz in synthetic units)
                mask = (f>=0.8) & (f<=1.2)
                C[i,j] = np.nanmean(c[mask]) if np.any(mask) else np.nanmean(c)
                C[j,i] = C[i,j]
    return C

def first_mode(streams):
    X = np.vstack(streams)  # N x T
    X = np.nan_to_num(X)
    Xc = (X - X.mean(axis=1, keepdims=True))
    pca = PCA(n_components=1)
    comp = pca.fit_transform(Xc.T).ravel()  # T
    var_expl = pca.explained_variance_ratio_[0]
    return comp, var_expl

def phase_gap(component, reference):
    # analytic phases
    ca = hilbert(component)
    ra = hilbert(reference)
    theta_c = np.unwrap(np.angle(ca))
    theta_r = np.unwrap(np.angle(ra))
    dphi = theta_c - theta_r
    return dphi

def time_to_overlap(dphi, t, eps=1e-4):
    # estimate instantaneous slope at the end
    if len(t) < 5:
        return np.nan
    # simple local linear fit near end
    t_end = t[-50:]
    p_end = dphi[-50:]
    A = np.vstack([t_end, np.ones_like(t_end)]).T
    m, b = np.linalg.lstsq(A, p_end, rcond=None)[0]
    # time to zero phase gap (if closing)
    slope = m
    current = abs(dphi[-1])
    if slope >= 0:
        return np.inf
    return current / max(eps, -slope)

def gti_metric(streams, component, reference, Cmat, var_expl):
    # median pairwise coherence
    n = Cmat.shape[0]
    vals = []
    for i in range(n):
        for j in range(i+1, n):
            vals.append(Cmat[i,j])
    coh = float(np.median(vals)) if vals else 0.0
    # phase penalty
    dphi = phase_gap(component, reference)
    phase_pen = np.exp(-abs(dphi))
    # aggregate: take the last value as headline, but return the series too
    gti_series = coh * var_expl * phase_pen
    return float(gti_series[-1]), gti_series, dphi

