
import os, numpy as np, pandas as pd

outdir = os.path.join(os.path.dirname(__file__), "data")
os.makedirs(outdir, exist_ok=True)

# Time base
T = 4000
t = np.linspace(0, 100, T)  # arbitrary units

# Our reference Sun-clock baseline (synthetic)
f = 1.0
phi_ref = 0.0
a = np.sin(2*np.pi*f*t + phi_ref)

# Incoming phase gap decays
phi_gap0 = np.deg2rad(40.0)
phi_gap = phi_gap0 * np.exp(-t/35.0)

# Create 4 streams = reference + incoming-mixed + noise variants
rng = np.random.default_rng(42)
streams = {}
for k in range(4):
    # Each stream is a mix: alpha * a + beta * incoming + noise
    alpha = 0.6 + 0.2*rng.random()
    beta  = 0.4 + 0.2*rng.random()
    incoming = np.sin(2*np.pi*f*t + phi_gap)
    noise = 0.02*rng.standard_normal(T)
    x = alpha*a + beta*incoming + noise
    streams[f"stream_{k+1}"] = x

import pandas as pd
for name, x in streams.items():
    df = pd.DataFrame({"t": t, "value": x})
    df.to_csv(os.path.join(outdir, f"{name}.csv"), index=False)

# also save reference a(t) for phase comparison
pd.DataFrame({"t": t, "a_ref": a}).to_csv(os.path.join(outdir, "reference.csv"), index=False)

print(f"Wrote {len(streams)} streams and reference to {outdir}")
