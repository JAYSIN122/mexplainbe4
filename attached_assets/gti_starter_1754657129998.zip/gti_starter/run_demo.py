
import os, json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from gti_pipeline import whiten, pairwise_coherence, first_mode, phase_gap, time_to_overlap, gti_metric

root = os.path.dirname(__file__)
datadir = os.path.join(root, "data")
outdir  = os.path.join(root, "outputs")
os.makedirs(outdir, exist_ok=True)

# Load synthetic streams
stream_files = sorted([f for f in os.listdir(datadir) if f.startswith("stream_") and f.endswith(".csv")])
streams = []
for fpath in stream_files:
    df = pd.read_csv(os.path.join(datadir, fpath))
    streams.append(whiten(df["value"].values))

ref = pd.read_csv(os.path.join(datadir, "reference.csv"))
t = ref["t"].values
a_ref = whiten(ref["a_ref"].values)

# Compute coherence matrix
Cmat = pairwise_coherence(streams, fs=20.0, nperseg=512)

# Extract first mode
comp, var_expl = first_mode(streams)

# Phase gap & GTI
dphi = phase_gap(comp, a_ref)
T_overlap = time_to_overlap(dphi, t)
gti_last, gti_series, _ = gti_metric(streams, comp, a_ref, Cmat, var_expl)

# --- Plots ---
# 1) Component vs reference (zoom)
mask = (t>=0) & (t<=20)
plt.figure(figsize=(9,4))
plt.plot(t[mask], a_ref[mask], label="Reference (our Sun-clock, synthetic)")
plt.plot(t[mask], comp[mask], label="Extracted common component", alpha=0.9)
plt.title("Common Component vs. Reference (zoom)")
plt.xlabel("t (arb.)"); plt.ylabel("normalized"); plt.legend(); plt.tight_layout()
plt.savefig(os.path.join(outdir, "component_vs_reference.png"), dpi=150)

# 2) Phase gap
plt.figure(figsize=(9,4))
plt.plot(t, np.degrees(dphi))
plt.title("Phase gap Δφ(t) [degrees]")
plt.xlabel("t (arb.)"); plt.ylabel("deg"); plt.tight_layout()
plt.savefig(os.path.join(outdir, "phase_gap.png"), dpi=150)

# 3) GTI series
plt.figure(figsize=(9,4))
plt.plot(t, gti_series)
plt.title("GTI(t) (demo metric)")
plt.xlabel("t (arb.)"); plt.ylabel("unitless"); plt.tight_layout()
plt.savefig(os.path.join(outdir, "gti_series.png"), dpi=150)

# Save metrics
metrics = {
    "var_explained_first_mode": float(var_expl),
    "median_pairwise_coherence": float(np.median(Cmat[np.triu_indices(len(streams),1)])) if len(streams)>=2 else 1.0,
    "GTI_last": float(gti_last),
    "phase_gap_last_deg": float(np.degrees(dphi[-1])),
    "T_overlap_estimate_time_units": float(T_overlap)
}
with open(os.path.join(outdir, "metrics.json"), "w") as f:
    json.dump(metrics, f, indent=2)

print("Wrote outputs to", outdir)
